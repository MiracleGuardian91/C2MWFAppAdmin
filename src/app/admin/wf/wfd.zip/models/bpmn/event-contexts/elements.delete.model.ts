import { DiagramEl } from "../element.model";

export type ElementsDeleteRule = {
  elements: DiagramEl[];
}