import { DiagramEl } from "../element.model";

export type ElementAutoResizeRule = {
  elements: DiagramEl[],
  target: DiagramEl,
}