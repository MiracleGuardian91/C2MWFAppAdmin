export type ElementsIds = {
  workflowIds: string[],
  stageIds: string[],
  stateIds: string[],
  triggerIds: string[],
  conditionIds: string[],
};