export interface EndStateItem {
  WfoSId:           string;
  StateName:        string;
  StateDisplayName: string;
}
