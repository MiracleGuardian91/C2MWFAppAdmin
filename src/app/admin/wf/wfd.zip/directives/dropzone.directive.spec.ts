import { DropzoneDirective } from './dropzone.directive';

describe('DropzoneDirective', () => {
  it('should create an instance', () => {
    const directive = new DropzoneDirective();
    expect(directive).toBeTruthy();
  });
});
