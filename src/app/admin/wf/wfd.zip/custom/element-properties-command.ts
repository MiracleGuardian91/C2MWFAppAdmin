import CommandInterceptor from 'diagram-js/lib/command/CommandInterceptor';

export class ElementPropertiesCommand extends CommandInterceptor {
  private modeling: any;
  private elementRegistry: any;
  private eventBus: any;

  constructor(eventBus, modeling, elementRegistry) {
    super(eventBus);

    this.eventBus = eventBus;
    this.modeling = modeling;
    this.elementRegistry = elementRegistry;

    this.preExecute('element.updateProperties', (event) => {
      const context = event.context;
      const element = context.element;
      const properties = context.properties;

      if (this.isElementPropertyChange(properties)) {
        if (!context.oldElementProperties) {
          context.oldElementProperties =
            this.getCurrentElementProperties(element);
        }
      }
    });

    this.executed('element.updateProperties', (event) => {
      const context = event.context;
      const element = context.element;
      const properties = context.properties;

      if (this.isElementPropertyChange(properties)) {
        this.applyElementPropertiesToElement(element, properties);
        this.eventBus.fire('element.changed', { element });
      }
    });

    this.reverted('element.updateProperties', (event) => {
      const context = event.context;
      const element = context.element;
      const oldElementProperties = context.oldElementProperties;

      if (
        oldElementProperties &&
        this.isElementPropertyChange(context.properties)
      ) {
        this.applyElementPropertiesToElement(element, oldElementProperties);
        this.eventBus.fire('element.changed', { element });
      }
    });
  }

  private isElementPropertyChange(properties: any): boolean {
    return (
      properties.fontFamily !== undefined ||
      properties.fontSize !== undefined ||
      properties.fontColor !== undefined ||
      properties.fontBold !== undefined ||
      properties.fontItalic !== undefined ||
      properties.fontUnderline !== undefined ||
      properties.alignment !== undefined ||
      properties.verticalAlignment !== undefined ||
      properties.horizontalAlignment !== undefined
    );
  }

  private getCurrentElementProperties(element: any): any {
    const bo = element.businessObject;
    return {
      fontFamily: bo?.fontFamily || element.fontFamily || 'Arial',
      fontSize: bo?.fontSize || element.fontSize || '14px',
      fontColor: bo?.fontColor || element.fontColor || '#000000',
      fontBold: bo?.fontBold || element.fontBold || false,
      fontItalic: bo?.fontItalic || element.fontItalic || false,
      fontUnderline: bo?.fontUnderline || element.fontUnderline || false,
      alignment: bo?.alignment || element.alignment || 'center',
      verticalAlignment:
        bo?.verticalAlignment || element.verticalAlignment || 'middle',
      horizontalAlignment:
        bo?.horizontalAlignment || element.horizontalAlignment || 'center',
    };
  }

  private applyElementPropertiesToElement(element: any, properties: any): void {
    const bo = element.businessObject;
    if (bo) {
      if (properties.fontFamily !== undefined)
        bo.fontFamily = properties.fontFamily;
      if (properties.fontSize !== undefined) bo.fontSize = properties.fontSize;
      if (properties.fontColor !== undefined)
        bo.fontColor = properties.fontColor;
      if (properties.fontBold !== undefined) bo.fontBold = properties.fontBold;
      if (properties.fontItalic !== undefined)
        bo.fontItalic = properties.fontItalic;
      if (properties.fontUnderline !== undefined)
        bo.fontUnderline = properties.fontUnderline;
      if (properties.alignment !== undefined)
        bo.alignment = properties.alignment;
      if (properties.verticalAlignment !== undefined)
        bo.verticalAlignment = properties.verticalAlignment;
      if (properties.horizontalAlignment !== undefined)
        bo.horizontalAlignment = properties.horizontalAlignment;
    }

    if (properties.fontFamily !== undefined)
      element.fontFamily = properties.fontFamily;
    if (properties.fontSize !== undefined)
      element.fontSize = properties.fontSize;
    if (properties.fontColor !== undefined)
      element.fontColor = properties.fontColor;
    if (properties.fontBold !== undefined)
      element.fontBold = properties.fontBold;
    if (properties.fontItalic !== undefined)
      element.fontItalic = properties.fontItalic;
    if (properties.fontUnderline !== undefined)
      element.fontUnderline = properties.fontUnderline;
    if (properties.alignment !== undefined)
      element.alignment = properties.alignment;
    if (properties.verticalAlignment !== undefined)
      element.verticalAlignment = properties.verticalAlignment;
    if (properties.horizontalAlignment !== undefined)
      element.horizontalAlignment = properties.horizontalAlignment;

    this.updateTextElements(element, properties);
  }

  private updateTextElements(element: any, properties: any): void {
    const gfx = this.elementRegistry.getGraphics(element.id);
    if (!gfx) return;

    const textElements = gfx.querySelectorAll('text');
    textElements.forEach((textEl: SVGTextElement) => {
      if (properties.fontFamily !== undefined) {
        textEl.setAttribute('font-family', properties.fontFamily);
      }
      if (properties.fontSize !== undefined) {
        textEl.setAttribute('font-size', properties.fontSize);
      }
      if (properties.fontColor !== undefined) {
        textEl.setAttribute('fill', properties.fontColor);
      }
      if (properties.fontBold !== undefined) {
        textEl.setAttribute(
          'font-weight',
          properties.fontBold ? 'bold' : 'normal'
        );
      }
      if (properties.fontItalic !== undefined) {
        textEl.setAttribute(
          'font-style',
          properties.fontItalic ? 'italic' : 'normal'
        );
      }
      if (properties.fontUnderline !== undefined) {
        textEl.setAttribute(
          'text-decoration',
          properties.fontUnderline ? 'underline' : 'none'
        );
      }
      if (properties.alignment !== undefined) {
        textEl.setAttribute(
          'text-anchor',
          this.getTextAnchor(properties.alignment)
        );
      }
      if (properties.verticalAlignment !== undefined) {
        textEl.setAttribute(
          'dominant-baseline',
          this.getDominantBaseline(properties.verticalAlignment)
        );
      }
    });

    const tspanElements = gfx.querySelectorAll('tspan');
    tspanElements.forEach((tspanEl: SVGTSpanElement) => {
      if (properties.fontFamily !== undefined) {
        tspanEl.setAttribute('font-family', properties.fontFamily);
      }
      if (properties.fontSize !== undefined) {
        tspanEl.setAttribute('font-size', properties.fontSize);
      }
      if (properties.fontColor !== undefined) {
        tspanEl.setAttribute('fill', properties.fontColor);
      }
      if (properties.fontBold !== undefined) {
        tspanEl.setAttribute(
          'font-weight',
          properties.fontBold ? 'bold' : 'normal'
        );
      }
      if (properties.fontItalic !== undefined) {
        tspanEl.setAttribute(
          'font-style',
          properties.fontItalic ? 'italic' : 'normal'
        );
      }
      if (properties.fontUnderline !== undefined) {
        tspanEl.setAttribute(
          'text-decoration',
          properties.fontUnderline ? 'underline' : 'none'
        );
      }
      if (properties.alignment !== undefined) {
        tspanEl.setAttribute(
          'text-anchor',
          this.getTextAnchor(properties.alignment)
        );
      }
      if (properties.verticalAlignment !== undefined) {
        tspanEl.setAttribute(
          'dominant-baseline',
          this.getDominantBaseline(properties.verticalAlignment)
        );
      }
    });
  }

  private getTextAnchor(alignment: string): string {
    switch (alignment) {
      case 'left':
        return 'start';
      case 'center':
        return 'middle';
      case 'right':
        return 'end';
      default:
        return 'middle';
    }
  }

  private getDominantBaseline(verticalAlignment: string): string {
    switch (verticalAlignment) {
      case 'top':
        return 'text-before-edge';
      case 'middle':
        return 'central';
      case 'bottom':
        return 'text-after-edge';
      default:
        return 'central';
    }
  }

  static $inject = ['eventBus', 'modeling', 'elementRegistry'];
}
